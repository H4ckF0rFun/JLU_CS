//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NurbsSurface.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_NURBSSTYPE                  129
#define IDD_MODIFY_ROTATON              130
#define IDD_MODIFY_COLOR                131
#define IDD_MODIFY_INNERWEIGHT          132
#define IDC_WEIGHT                      1000
#define IDC_XVALUE                      1001
#define IDC_YVALUE                      1002
#define IDC_ZVALUE                      1003
#define IDC_ANGLE                       1004
#define IDC_RED                         1005
#define IDC_GREEN                       1006
#define IDC_BLUE                        1007
#define ID_MODIFY_INNERWEIGHT           32771
#define ID_MODIFY_ROTATION              32773
#define ID_MODIFY_COLOR                 32774
#define ID_SHOW_CTRLNET                 32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
